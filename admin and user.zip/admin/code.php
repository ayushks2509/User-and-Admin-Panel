<?php

include('secuirity.php');

$connection = mysqli_connect("localhost","root","","adminpanel");



// if(isset($_POST['login_btn']))
// {
//     $email_login = $_POST['emaill']; 
//     $password_login = $_POST['passwordd']; 

//     $login_query = "SELECT * FROM register WHERE email='$email_login' AND password='$password_login' LIMIT 1";
//     $login_query_run = mysqli_query($connection, $login_query);
//     // $usertypes = mysqli_fetch_array($login_query_run);

//     if(mysqli_num_rows($login_query_run) > 0)
//     {
//         foreach($login_query_run as $data)
//         {
//             $user_id = $data['id'];
//             $user_name = $data['username'];
//             $user_email = $data['email'];
//             $role_as = $data['usertype'];
//         }


//         $_SESSION['auth'] = true;
//         $_SESSION['auth_role'] = "$role_as";
//         $_SESSION['auth_user'] = [
//             'user-id' =>$user_id,
//             'user-name' =>$user_name,
//             'user-email' =>$user_email,

//         ];
//         // header('Location: login.php');
//     }
//     else if($email_login==null && $password_login==null){
//         $_SESSION['status'] = "Please enter every field";
//         $_SESSION['status_code'] = "error";
//         header('Location: login.php');
//         // exit(0);
//     }
//     else if($email_login==null){
//         $_SESSION['status'] = "Email can't be null";
//         $_SESSION['status_code'] = "error";
//         header('Location: login.php');
//     }
//     else if($password_login==null){
//         $_SESSION['status'] = "Password can't be null";
//         $_SESSION['status_code'] = "error";
//         header('Location: login.php');
//     }

//     else if($_SESSION['auth_role'] == "admin")
//     {
//         $_SESSION['username'] = $email_login;
//         header('Location: admin_list.php');
//     }
//     else if($_SESSION['auth_role'] == "user")
//     {
//         $_SESSION['username'] = $email_login;
//         header('Location: user_list.php');
//     }
//     else
//     {
//         $_SESSION['status'] = "Email / Password is Invalid";
//         header('Location: login.php');
//     }
// }


if(isset($_POST['login_btn']))
{
    $email_login = $_POST['emaill']; 
    $password_login = $_POST['passwordd']; 

    $query = "SELECT * FROM register WHERE email='$email_login' LIMIT 1";
    $query_run = mysqli_query($connection, $query);
    $result = mysqli_fetch_array($query_run);

    if(password_verify($password_login,$result['password'])){
        if($email_login==null && $password_login==null){
            $_SESSION['status'] = "Please enter every field";
            $_SESSION['status_code'] = "error";
            header('Location: login.php');
        }
        else if($email_login==null){
            $_SESSION['status'] = "Email can't be null";
            $_SESSION['status_code'] = "error";
            header('Location: login.php');
        }   
        else if($result['usertype'] == "admin")
        {
            $_SESSION['username'] = $email_login;
            $_SESSION['usertype'] = "admin";
            header('Location: admin_list.php');
        }
        else if($result['usertype'] == "user")
        {
            $_SESSION['username'] = $email_login;
            $_SESSION['usertype'] = "user";
            header('Location: user_list.php');
        }
        else
        {
            $_SESSION['status'] = "Email / Password is Invalid";
            header('Location: login.php');
        }
    }
    else if($password_login==null){
        $_SESSION['status'] = "Password can't be null";
        $_SESSION['status_code'] = "error";
        header('Location: login.php');
    }
    else{
        $_SESSION['status'] = "Wrong password";
        $_SESSION['status_code'] = "error";
        header('Location: login.php');
    }
    
}

if(isset($_POST['register_btn']))
{
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['confirmpassword'];
    $usertype = $_POST['usertype'];
    
    $email_query = "SELECT * FROM register WHERE email='$email' ";
    $email_query_run = mysqli_query($connection, $email_query);
    if($username==null && $email==null && $password==null && $cpassword==null && $usertype==null){
        $_SESSION['status'] = "Please enter every field";
        $_SESSION['status_code'] = "error";
        header('Location: register.php');
    }

    
    else if($username==null){
        $_SESSION['status'] = "Username can`t be null";
        $_SESSION['status_code'] = "error";
        header('Location: register.php'); 
    }
    else if (!preg_match ("/^[a-zA-z]*$/", $username) ) {  
        $_SESSION['status'] = "Only alphabets and whitespace are allowed.";  
        $_SESSION['status_code'] = "error";
        header('Location: register.php');         
      }
    else if($email==null){
        $_SESSION['status'] = "Email can`t be null";
        $_SESSION['status_code'] = "error";
        header('Location: register.php'); 
    }
    else if (!filter_var($email, FILTER_VALIDATE_EMAIL)){  
        $_SESSION['status'] = "Email is not valid.";   
        $_SESSION['status_code'] = "error";
        header('Location: register.php');  
            
} 
    else if(mysqli_num_rows($email_query_run) > 0)
    {
        $_SESSION['status'] = "Email Already Taken. Please Try Another one.";
        $_SESSION['status_code'] = "error";
        header('Location: register.php');  
    }
    else if($usertype==null){
        $_SESSION['status'] = "Usertype can`t be null";
        $_SESSION['status_code'] = "error";
        header('Location: register.php'); 
    }
    else if($password==null){
        $_SESSION['status'] = "Password can`t be null";
        $_SESSION['status_code'] = "error";
        header('Location: register.php'); 
    }
    else if($cpassword==null){
        $_SESSION['status'] = "Confirm Password can`t be null";
        $_SESSION['status_code'] = "error";
        header('Location: register.php'); 
    }
    
    
    else 
    {
        if($password == $cpassword)
        {
            $hash = password_hash($password,PASSWORD_DEFAULT);
            $query = "INSERT INTO register (username,email,password,usertype) VALUES ('$username','$email','$hash','$usertype')";
            $query_run = mysqli_query($connection, $query);
            
            if($query_run)
            {
                // echo "Saved";
                $_SESSION['status'] = "User Profile Added";
                $_SESSION['status_code'] = "success";
                header('Location: login.php');
            }
            else 
            {
                $_SESSION['status'] = "Admin Profile Not Added";
                $_SESSION['status_code'] = "error";
                header('Location: register.php');  
            }
        }
        else 
        {
            $_SESSION['status'] = "Password and Confirm Password Does Not Match";
            $_SESSION['status_code'] = "warning";
            header('Location: register.php');  
        }
    }

}

if(isset($_POST['registerbtn']))
{
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['confirmpassword'];
    $usertype = $_POST['usertype'];
    
    $email_query = "SELECT * FROM register WHERE email='$email' ";
    $email_query_run = mysqli_query($connection, $email_query);
    if($username==null && $email==null && $password==null && $cpassword==null){
        $_SESSION['status'] = "Please enter every field";
        $_SESSION['status_code'] = "error";
        header('Location: admin_list.php');
    }
    else if($username==null){
        $_SESSION['status'] = "Username can`t be null";
        $_SESSION['status_code'] = "error";
        header('Location: admin_list.php'); 
    }
    else if($email==null){
        $_SESSION['status'] = "Email can`t be null";
        $_SESSION['status_code'] = "error";
        header('Location: admin_list.php');
    }
    else if(mysqli_num_rows($email_query_run) > 0)
    {
        $_SESSION['status'] = "Email Already Taken. Please Try Another one.";
        $_SESSION['status_code'] = "error";
        header('Location: admin_list.php');  
    }
    else if($password==null){
        $_SESSION['status'] = "Password can`t be null";
        $_SESSION['status_code'] = "error";
        header('Location: admin_list.php');
    }
    
    
    else
    {
        if($password === $cpassword)
        {
            $hash = password_hash($password,PASSWORD_DEFAULT);
            $query = "INSERT INTO register (username,email,password,usertype) VALUES ('$username','$email','$hash','$usertype')";
            $query_run = mysqli_query($connection, $query);
            
            if($query_run)
            {
                // echo "Saved";
                $_SESSION['status'] = "Admin Profile Added";
                $_SESSION['status_code'] = "success";
                header('Location: admin_list.php');
            }
            else 
            {
                $_SESSION['status'] = "Admin Profile Not Added";
                $_SESSION['status_code'] = "error";
                header('Location: admin_list.php');  
            }
        }
        else 
        {
            $_SESSION['status'] = "Password and Confirm Password Does Not Match";
            $_SESSION['status_code'] = "warning";
            header('Location: admin_list.php');  
        }
    }

}


if(isset($_POST['updatebtn']))
{
    $id = $_POST['edit_id'];
    $username = $_POST['edit_username'];
    $email = $_POST['edit_email'];
    $password = $_POST['edit_password'];
    $usertypeupdate = $_POST['update_usertype'];
    $hash = password_hash($password,PASSWORD_DEFAULT);
    
    
    if($password=='●●●●'){
        $query = "UPDATE register SET username='$username', email='$email', usertype='$usertypeupdate' WHERE id='$id' ";
    }else{
        $query = "UPDATE register SET username='$username', email='$email', password='$hash', usertype='$usertypeupdate' WHERE id='$id' ";
    
    }

   $query_run = mysqli_query($connection, $query);




    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: admin_list.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: admin_list.php'); 
    }


}




if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM register WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Data is Deleted";
        $_SESSION['status_code'] = "success";
        header('Location: admin_list.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";       
        $_SESSION['status_code'] = "error";
        header('Location: admin_list.php'); 
    }    
}






?>
