<?php


if($_SESSION['usertype'] === "user")
    {
        $_SESSION['status'] = "You are not an admin";
        header('Location: user_list.php');
        exit(0);
    }

    ?> 