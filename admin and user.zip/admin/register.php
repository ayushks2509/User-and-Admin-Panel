<?php
include('secuirity.php');

include('includes/header.php');

?>



<div class="container">
    <!-- Outer Row -->
    <div class="row justify-content-center">
        <div class="col-xl-6 col-lg-6 col-md-6">
            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">Register Here!</h1>
                                    <?php
                                    if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
                                        echo '<h2 class="bg-danger text-white"> ' . $_SESSION['status'] . ' </h2>';
                                        unset($_SESSION['status']);
                                    }
                                    ?>
                                </div>
                                <form class="user" action="code.php" method="POST">
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label> Username </label>
                                            <input type="text" maxlength="30" name="username" class="form-control " placeholder="Enter Username">
                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="text" maxlength="40" name="email" class="form-control " placeholder="Enter Email">
                                            <small class="error_email" style="color: red;"></small>
                                        </div>
                                        <div class="form-group">
                                            <label>Usertype</label>
                                            <select name="usertype" class="form-control ">
                                                <option value="" disabled selected hidden>--Choose Usertype--</option>
                                                <option value="admin">Admin</option>
                                                <option value="user">User</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" name="password" class="form-control " placeholder="Enter Password">
                                        </div>
                                        <div class="form-group">
                                            <label>Confirm Password</label>
                                            <input type="password" name="confirmpassword" class="form-control " placeholder="Confirm Password">
                                        </div>



                                    </div>

                                    <button type="submit" name="register_btn" class="btn btn-primary  btn-block">Register Now</button>




                                    <div class="modal-footer">
                                        <a href="login.php">Already a user</a>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>






<?php
include('includes/scripts.php');
// include('includes/footer.php');
?>